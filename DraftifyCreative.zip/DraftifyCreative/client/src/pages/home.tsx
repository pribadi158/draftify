import { useState, useEffect } from "react";
import { Button } from "@/components/ui/button";
import { Card, CardContent } from "@/components/ui/card";
import { 
  Globe, 
  Palette, 
  PenTool, 
  Video, 
  Smartphone, 
  Layout, 
  BarChart3, 
  Presentation,
  Star,
  ArrowRight,
  Menu,
  X,
  Mail,
  Phone,
  MapPin,
  Facebook,
  Twitter,
  Instagram,
  Linkedin,
  MessageCircle,
  Check
} from "lucide-react";

export default function Home() {
  const [mobileMenuOpen, setMobileMenuOpen] = useState(false);
  const [navVisible, setNavVisible] = useState(true);
  const [lastScrollY, setLastScrollY] = useState(0);

  useEffect(() => {
    const handleScroll = () => {
      const currentScrollY = window.scrollY;
      
      if (currentScrollY > lastScrollY && currentScrollY > 100) {
        setNavVisible(false);
      } else {
        setNavVisible(true);
      }
      
      setLastScrollY(currentScrollY);
    };

    window.addEventListener('scroll', handleScroll);
    return () => window.removeEventListener('scroll', handleScroll);
  }, [lastScrollY]);

  const scrollToSection = (sectionId: string) => {
    const element = document.getElementById(sectionId);
    if (element) {
      const navHeight = 64; // Height of fixed nav
      const elementPosition = element.offsetTop - navHeight;
      window.scrollTo({
        top: elementPosition,
        behavior: 'smooth'
      });
    }
    setMobileMenuOpen(false);
  };

  const services = [
    {
      icon: Globe,
      title: "Website",
      description: "Pembuatan website profesional dan responsif sesuai kebutuhan bisnis Anda"
    },
    {
      icon: Palette,
      title: "Desain Branding",
      description: "Menciptakan identitas visual yang kuat dan memorable untuk brand Anda"
    },
    {
      icon: PenTool,
      title: "Copywriting",
      description: "Penulisan konten yang persuasif dan engaging untuk berbagai kebutuhan"
    },
    {
      icon: Video,
      title: "Video Editing",
      description: "Editing video profesional untuk konten promosi dan corporate"
    },
    {
      icon: Smartphone,
      title: "Mockup Aplikasi",
      description: "Desain mockup aplikasi mobile yang user-friendly dan modern"
    },
    {
      icon: Layout,
      title: "UI/UX Prototype",
      description: "Prototype interaktif untuk pengalaman pengguna yang optimal"
    },
    {
      icon: BarChart3,
      title: "Dashboard Digital",
      description: "Dashboard interaktif untuk monitoring dan analisis data bisnis"
    },
    {
      icon: Presentation,
      title: "Materi Presentasi",
      description: "Slide presentasi yang menarik dan profesional untuk bisnis Anda"
    }
  ];

  const projects = [
    {
      image: "https://images.unsplash.com/photo-1559136555-9303baea8ebd?ixlib=rb-4.0.3&ixid=MnwxMjA3fDB8MHxwaG90by1wYWdlfHx8fGVufDB8fHx8&auto=format&fit=crop&w=800&h=600",
      title: "FoodieApp Mobile",
      description: "Aplikasi mobile untuk food delivery dengan UI/UX yang user-friendly dan modern",
      category: "UI/UX Design"
    },
    {
      image: "https://images.unsplash.com/photo-1542744173-8e7e53415bb0?ixlib=rb-4.0.3&ixid=MnwxMjA3fDB8MHxwaG90by1wYWdlfHx8fGVufDB8fHx8&auto=format&fit=crop&w=800&h=600",
      title: "TechCorp Dashboard",
      description: "Dashboard analytics untuk monitoring performa bisnis dengan data visualization yang menarik",
      category: "Dashboard Digital"
    },
    {
      image: "https://images.unsplash.com/photo-1551288049-bebda4e38f71?ixlib=rb-4.0.3&ixid=MnwxMjA3fDB8MHxwaG90by1wYWdlfHx8fGVufDB8fHx8&auto=format&fit=crop&w=800&h=600",
      title: "GreenLeaf Website",
      description: "Website company profile untuk perusahaan environmental dengan desain yang clean dan fresh",
      category: "Website"
    },
    {
      image: "https://images.unsplash.com/photo-1493421419110-74f4e85ba126?ixlib=rb-4.0.3&ixid=MnwxMjA3fDB8MHxwaG90by1wYWdlfHx8fGVufDB8fHx8&auto=format&fit=crop&w=800&h=600",
      title: "StyleHub Branding",
      description: "Paket branding lengkap untuk fashion startup termasuk logo, brand guidelines, dan merchandise",
      category: "Branding"
    },
    {
      image: "https://images.unsplash.com/photo-1531403009284-440f080d1e12?ixlib=rb-4.0.3&ixid=MnwxMjA3fDB8MHxwaG90by1wYWdlfHx8fGVufDB8fHx8&auto=format&fit=crop&w=800&h=600",
      title: "FinanceFlow Presentation",
      description: "Slide deck presentation untuk company profile fintech dengan visualisasi data yang compelling",
      category: "Presentation"
    }
  ];

  const testimonials = [
    {
      name: "Sarah Wijaya",
      role: "CEO TechStartup",
      content: "Konsep spec work Draftify sangat membantu kami dalam mengambil keputusan. Bisa melihat hasil dulu sebelum commit, sangat recommended!",
      rating: 5
    },
    {
      name: "Budi Santoso",
      role: "Marketing Director",
      content: "Kualitas kerja Draftify luar biasa. Tim yang profesional dan hasil yang memuaskan. Pasti akan kerjasama lagi untuk proyek berikutnya.",
      rating: 5
    },
    {
      name: "Maya Indira",
      role: "Creative Director",
      content: "Metode spec work yang unik dan transparan. Kami bisa melihat preview hasil kerja sebelum memutuskan. Pelayanan yang sangat customer-centric.",
      rating: 5
    }
  ];

  const workSteps = [
    {
      number: "1",
      title: "Pilih Layanan",
      description: "Tentukan layanan yang Anda butuhkan dari berbagai pilihan yang tersedia"
    },
    {
      number: "2",
      title: "Kami Buat Contoh Gratis",
      description: "Tim ahli kami akan membuat contoh kerja sesuai kebutuhan Anda tanpa biaya"
    },
    {
      number: "3",
      title: "Anda Review",
      description: "Evaluasi hasil kerja kami dan berikan feedback untuk penyempurnaan"
    },
    {
      number: "4",
      title: "Website Siap Tayang",
      description: "Setelah disetujui, proyek Anda akan diselesaikan dan siap untuk digunakan"
    }
  ];

  return (
    <div className="min-h-screen bg-white">
      {/* Navigation */}
      <nav className={`fixed top-0 left-0 right-0 bg-white shadow-lg z-50 transition-transform duration-300 ${navVisible ? 'translate-y-0' : '-translate-y-full'}`}>
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <div className="flex justify-between items-center h-16">
            <div className="flex items-center">
              <div className="text-2xl font-bold text-draftify-blue">Draftify</div>
            </div>
            
            {/* Desktop Navigation */}
            <div className="hidden md:block">
              <div className="ml-10 flex items-baseline space-x-8">
                <button 
                  onClick={() => scrollToSection('beranda')}
                  className="text-gray-700 hover:text-draftify-blue px-3 py-2 text-sm font-medium transition-colors"
                >
                  Beranda
                </button>
                <button 
                  onClick={() => scrollToSection('layanan')}
                  className="text-gray-700 hover:text-draftify-blue px-3 py-2 text-sm font-medium transition-colors"
                >
                  Layanan
                </button>
                <button 
                  onClick={() => scrollToSection('cara-kerja')}
                  className="text-gray-700 hover:text-draftify-blue px-3 py-2 text-sm font-medium transition-colors"
                >
                  Cara Kerja
                </button>
                <button 
                  onClick={() => scrollToSection('showcase')}
                  className="text-gray-700 hover:text-draftify-blue px-3 py-2 text-sm font-medium transition-colors"
                >
                  Portfolio
                </button>
                <button 
                  onClick={() => scrollToSection('testimoni')}
                  className="text-gray-700 hover:text-draftify-blue px-3 py-2 text-sm font-medium transition-colors"
                >
                  Testimoni
                </button>
                <Button 
                  onClick={() => scrollToSection('kontak')}
                  className="bg-draftify-blue hover:bg-blue-800 text-white px-4 py-2 text-sm font-medium"
                >
                  Kontak
                </Button>
              </div>
            </div>
            
            {/* Mobile menu button */}
            <div className="md:hidden">
              <Button
                variant="ghost"
                size="icon"
                onClick={() => setMobileMenuOpen(!mobileMenuOpen)}
                className="text-gray-700 hover:text-draftify-blue"
              >
                {mobileMenuOpen ? <X className="h-6 w-6" /> : <Menu className="h-6 w-6" />}
              </Button>
            </div>
          </div>
        </div>
        
        {/* Mobile Navigation */}
        {mobileMenuOpen && (
          <div className="md:hidden bg-white border-t">
            <div className="px-2 pt-2 pb-3 space-y-1">
              <button 
                onClick={() => scrollToSection('beranda')}
                className="block w-full text-left px-3 py-2 text-base font-medium text-gray-700 hover:text-draftify-blue"
              >
                Beranda
              </button>
              <button 
                onClick={() => scrollToSection('layanan')}
                className="block w-full text-left px-3 py-2 text-base font-medium text-gray-700 hover:text-draftify-blue"
              >
                Layanan
              </button>
              <button 
                onClick={() => scrollToSection('cara-kerja')}
                className="block w-full text-left px-3 py-2 text-base font-medium text-gray-700 hover:text-draftify-blue"
              >
                Cara Kerja
              </button>
              <button 
                onClick={() => scrollToSection('showcase')}
                className="block w-full text-left px-3 py-2 text-base font-medium text-gray-700 hover:text-draftify-blue"
              >
                Portfolio
              </button>
              <button 
                onClick={() => scrollToSection('testimoni')}
                className="block w-full text-left px-3 py-2 text-base font-medium text-gray-700 hover:text-draftify-blue"
              >
                Testimoni
              </button>
              <Button 
                onClick={() => scrollToSection('kontak')}
                className="block w-full text-left px-3 py-2 text-base font-medium bg-draftify-blue text-white"
              >
                Kontak
              </Button>
            </div>
          </div>
        )}
      </nav>

      {/* Hero Section */}
      <section id="beranda" className="pt-16 bg-gradient-to-br from-blue-50 to-white">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-20">
          <div className="grid grid-cols-1 lg:grid-cols-2 gap-12 items-center">
            <div>
              <h1 className="text-4xl md:text-5xl lg:text-6xl font-bold text-gray-900 mb-6">
                <span className="text-draftify-blue">Kami membuat dulu,</span><br />
                <span className="text-gray-700">Anda tinggal menyetujui.</span>
              </h1>
              <p className="text-xl text-gray-600 mb-8 leading-relaxed">
                Draftify menggunakan metode Spec Work untuk memberikan solusi kreatif terbaik. Lihat hasil kerja kami dulu, baru putuskan untuk melanjutkan.
              </p>
              <div className="flex flex-col sm:flex-row gap-4">
                <Button 
                  onClick={() => scrollToSection('layanan')}
                  className="bg-draftify-blue hover:bg-blue-800 text-white px-8 py-3 text-lg font-semibold"
                >
                  Lihat Layanan
                </Button>
                <Button 
                  onClick={() => scrollToSection('cara-kerja')}
                  variant="outline"
                  className="border-2 border-draftify-blue text-draftify-blue hover:bg-draftify-blue hover:text-white px-8 py-3 text-lg font-semibold"
                >
                  Cara Kerja
                </Button>
              </div>
            </div>
            <div className="relative">
              <img 
                src="https://images.unsplash.com/photo-1522071820081-009f0129c71c?ixlib=rb-4.0.3&ixid=MnwxMjA3fDB8MHxwaG90by1wYWdlfHx8fGVufDB8fHx8&auto=format&fit=crop&w=800&h=600" 
                alt="Modern office workspace" 
                className="rounded-2xl shadow-2xl w-full h-auto"
              />
              <div className="absolute -bottom-6 -left-6 bg-white p-6 rounded-xl shadow-lg">
                <div className="flex items-center space-x-3">
                  <div className="w-12 h-12 bg-green-100 rounded-full flex items-center justify-center">
                    <Check className="text-green-600 h-6 w-6" />
                  </div>
                  <div>
                    <p className="font-semibold text-gray-900">100% Satisfaction</p>
                    <p className="text-gray-600 text-sm">Guaranteed Results</p>
                  </div>
                </div>
              </div>
            </div>
          </div>
        </div>
      </section>

      {/* Services Section */}
      <section id="layanan" className="py-20 bg-white">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <div className="text-center mb-16">
            <h2 className="text-3xl md:text-4xl font-bold text-gray-900 mb-4">Layanan Kami</h2>
            <p className="text-xl text-gray-600 max-w-3xl mx-auto">
              Kami menyediakan berbagai layanan kreatif dengan pendekatan spec work yang inovatif
            </p>
          </div>
          <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-8">
            {services.map((service, index) => (
              <Card key={index} className="bg-gray-50 hover:bg-blue-50 transition-colors group border-none">
                <CardContent className="p-8">
                  <div className="w-16 h-16 bg-draftify-blue group-hover:bg-blue-600 rounded-lg flex items-center justify-center mb-6 transition-colors">
                    <service.icon className="text-white h-8 w-8" />
                  </div>
                  <h3 className="text-xl font-semibold text-gray-900 mb-3">{service.title}</h3>
                  <p className="text-gray-600">{service.description}</p>
                </CardContent>
              </Card>
            ))}
          </div>
        </div>
      </section>

      {/* How It Works Section */}
      <section id="cara-kerja" className="py-20 bg-gray-50">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <div className="text-center mb-16">
            <h2 className="text-3xl md:text-4xl font-bold text-gray-900 mb-4">Cara Kerja Kami</h2>
            <p className="text-xl text-gray-600 max-w-3xl mx-auto">
              Proses sederhana dan transparan untuk hasil yang memuaskan
            </p>
          </div>
          <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-8">
            {workSteps.map((step, index) => (
              <div key={index} className="text-center">
                <div className="relative mb-8">
                  <div className="w-20 h-20 bg-draftify-blue rounded-full flex items-center justify-center mx-auto mb-4">
                    <span className="text-white font-bold text-2xl">{step.number}</span>
                  </div>
                  {index < workSteps.length - 1 && (
                    <div className="hidden lg:block absolute top-10 left-full w-full h-1 bg-gray-200 -ml-10">
                      <div className="w-3/4 h-full bg-draftify-blue"></div>
                    </div>
                  )}
                </div>
                <h3 className="text-xl font-semibold text-gray-900 mb-3">{step.title}</h3>
                <p className="text-gray-600">{step.description}</p>
              </div>
            ))}
          </div>
        </div>
      </section>

      {/* Showcase Section */}
      <section id="showcase" className="py-20 bg-white">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <div className="text-center mb-16">
            <h2 className="text-3xl md:text-4xl font-bold text-gray-900 mb-4">Portfolio Proyek</h2>
            <p className="text-xl text-gray-600 max-w-3xl mx-auto">
              Lihat berbagai proyek yang telah kami kerjakan dengan metode spec work
            </p>
          </div>
          <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-8">
            {projects.map((project, index) => (
              <Card key={index} className="bg-white shadow-lg hover:shadow-xl transition-shadow border-none overflow-hidden">
                <img 
                  src={project.image} 
                  alt={project.title}
                  className="w-full h-48 object-cover"
                />
                <CardContent className="p-6">
                  <h3 className="text-xl font-semibold text-gray-900 mb-2">{project.title}</h3>
                  <p className="text-gray-600 mb-4">{project.description}</p>
                  <div className="flex justify-between items-center">
                    <span className="text-draftify-blue font-semibold">{project.category}</span>
                    <ArrowRight className="text-draftify-blue h-5 w-5" />
                  </div>
                </CardContent>
              </Card>
            ))}
          </div>
        </div>
      </section>

      {/* Testimonials Section */}
      <section id="testimoni" className="py-20 bg-gray-50">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <div className="text-center mb-16">
            <h2 className="text-3xl md:text-4xl font-bold text-gray-900 mb-4">Apa Kata Klien Kami</h2>
            <p className="text-xl text-gray-600 max-w-3xl mx-auto">
              Testimonial dari klien yang puas dengan layanan spec work kami
            </p>
          </div>
          <div className="grid grid-cols-1 md:grid-cols-3 gap-8">
            {testimonials.map((testimonial, index) => (
              <Card key={index} className="bg-white p-8 shadow-lg border-none">
                <CardContent className="p-0">
                  <div className="flex items-center mb-4">
                    <div className="flex text-yellow-400">
                      {[...Array(testimonial.rating)].map((_, i) => (
                        <Star key={i} className="h-5 w-5 fill-current" />
                      ))}
                    </div>
                  </div>
                  <p className="text-gray-600 mb-6 italic">"{testimonial.content}"</p>
                  <div className="flex items-center">
                    <div className="w-12 h-12 bg-gray-300 rounded-full flex items-center justify-center mr-4">
                      <span className="text-gray-600 font-semibold">
                        {testimonial.name.split(' ').map(n => n[0]).join('')}
                      </span>
                    </div>
                    <div>
                      <h4 className="font-semibold text-gray-900">{testimonial.name}</h4>
                      <p className="text-gray-600 text-sm">{testimonial.role}</p>
                    </div>
                  </div>
                </CardContent>
              </Card>
            ))}
          </div>
        </div>
      </section>

      {/* Call to Action Section */}
      <section id="kontak" className="py-20 bg-gradient-to-br from-blue-800 to-blue-900">
        <div className="max-w-4xl mx-auto px-4 sm:px-6 lg:px-8 text-center">
          <h2 className="text-3xl md:text-4xl font-bold text-white mb-6">
            Siap melihat hasilnya? Hubungi kami.
          </h2>
          <p className="text-xl text-blue-100 mb-8 max-w-2xl mx-auto">
            Mulai proyek Anda dengan metode spec work yang inovatif. Tim ahli kami siap membantu mewujudkan visi kreatif Anda.
          </p>
          <div className="flex flex-col sm:flex-row gap-4 justify-center">
            <Button 
              asChild
              className="bg-white hover:bg-gray-100 text-blue-800 px-8 py-3 text-lg font-semibold"
            >
              <a href="mailto:draftify.spark@gmail.com" className="inline-flex items-center">
                <Mail className="mr-2 h-5 w-5" />
                Email Kami
              </a>
            </Button>
            <Button 
              asChild
              className="bg-green-500 hover:bg-green-600 text-white px-8 py-3 text-lg font-semibold"
            >
              <a href="https://wa.me/6289671670522" className="inline-flex items-center">
                <MessageCircle className="mr-2 h-5 w-5" />
                WhatsApp
              </a>
            </Button>
          </div>
        </div>
      </section>

      {/* Footer */}
      <footer className="bg-gray-900 text-white py-12">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <div className="grid grid-cols-1 md:grid-cols-4 gap-8">
            <div className="md:col-span-2">
              <div className="text-2xl font-bold mb-4">Draftify</div>
              <p className="text-gray-400 mb-6 max-w-md">
                Solusi kreatif dengan metode spec work. Kami membuat dulu, Anda tinggal menyetujui.
              </p>
              <div className="flex space-x-4">
                <a href="#" className="text-gray-400 hover:text-white transition-colors">
                  <Facebook className="h-6 w-6" />
                </a>
                <a href="#" className="text-gray-400 hover:text-white transition-colors">
                  <Twitter className="h-6 w-6" />
                </a>
                <a href="#" className="text-gray-400 hover:text-white transition-colors">
                  <Instagram className="h-6 w-6" />
                </a>
                <a href="#" className="text-gray-400 hover:text-white transition-colors">
                  <Linkedin className="h-6 w-6" />
                </a>
              </div>
            </div>
            
            <div>
              <h3 className="text-lg font-semibold mb-4">Layanan</h3>
              <ul className="space-y-2 text-gray-400">
                <li><a href="#" className="hover:text-white transition-colors">Website</a></li>
                <li><a href="#" className="hover:text-white transition-colors">Branding</a></li>
                <li><a href="#" className="hover:text-white transition-colors">UI/UX Design</a></li>
                <li><a href="#" className="hover:text-white transition-colors">Copywriting</a></li>
              </ul>
            </div>
            
            <div>
              <h3 className="text-lg font-semibold mb-4">Kontak</h3>
              <ul className="space-y-2 text-gray-400">
                <li className="flex items-center">
                  <Mail className="mr-2 h-4 w-4" />
                  <a href="mailto:draftify.spark@gmail.com" className="hover:text-white transition-colors">
                    draftify.spark@gmail.com
                  </a>
                </li>
                <li className="flex items-center">
                  <MessageCircle className="mr-2 h-4 w-4" />
                  <a href="https://wa.me/6289671670522" className="hover:text-white transition-colors">
                    089671670522
                  </a>
                </li>
                <li className="flex items-center">
                  <MapPin className="mr-2 h-4 w-4" />
                  <span>Parung, Jawa Barat</span>
                </li>
              </ul>
            </div>
          </div>
          
          <div className="border-t border-gray-800 mt-8 pt-8 text-center text-gray-400">
            <p>&copy; 2024 Draftify. All rights reserved.</p>
          </div>
        </div>
      </footer>
    </div>
  );
}
