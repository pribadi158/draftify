# Draftify - Spec Work Solutions

## Overview

Draftify is a modern full-stack web application built for a creative agency that specializes in spec work solutions. The application is built using React with TypeScript for the frontend, Express.js for the backend, and PostgreSQL with Drizzle ORM for data persistence. The application follows a monorepo structure with separate client and server directories, sharing common types and schemas.

## System Architecture

### Frontend Architecture
- **Framework**: React 18 with TypeScript
- **Styling**: Tailwind CSS with shadcn/ui component library
- **State Management**: TanStack Query for server state management
- **Routing**: Wouter for client-side routing
- **UI Components**: Radix UI primitives with custom shadcn/ui components
- **Build Tool**: Vite for development and production builds

### Backend Architecture
- **Framework**: Express.js with TypeScript
- **Runtime**: Node.js with native ESM support
- **Database**: PostgreSQL with Drizzle ORM
- **Session Management**: Express sessions with PostgreSQL store
- **API Design**: RESTful API with JSON responses

### Development Environment
- **Package Manager**: npm
- **TypeScript**: Shared configuration across frontend and backend
- **Hot Reload**: Vite dev server with Express middleware integration
- **Database Migrations**: Drizzle Kit for schema management

## Key Components

### Database Layer
- **ORM**: Drizzle ORM with PostgreSQL dialect
- **Schema**: Centralized schema definitions in `/shared/schema.ts`
- **Migrations**: Generated and managed through Drizzle Kit
- **Connection**: Neon Database serverless PostgreSQL

### Authentication & User Management
- **User Schema**: Basic user table with username and password fields
- **Storage Interface**: Abstracted storage layer with in-memory fallback
- **Session Handling**: Ready for implementation with connect-pg-simple

### UI/UX Components
- **Design System**: shadcn/ui with "new-york" style variant
- **Theme**: Neutral color scheme with CSS custom properties
- **Responsive Design**: Mobile-first approach with Tailwind breakpoints
- **Accessibility**: Radix UI primitives ensure WCAG compliance

### State Management
- **Query Client**: TanStack Query for server state caching
- **Error Handling**: Centralized error boundaries and toast notifications
- **Loading States**: Built-in loading and error states for async operations

## Data Flow

### Client-Server Communication
1. **API Requests**: Centralized through `apiRequest` utility function
2. **Query Management**: TanStack Query handles caching, invalidation, and background updates
3. **Error Handling**: Automatic error boundary handling with user-friendly messages
4. **Authentication**: Cookie-based sessions with automatic request credential inclusion

### Database Operations
1. **Schema Definition**: Centralized schema in shared directory
2. **Type Safety**: Full TypeScript integration with Drizzle ORM
3. **Query Building**: Type-safe query construction with Drizzle syntax
4. **Migrations**: Version-controlled database schema changes

## External Dependencies

### Core Dependencies
- **@neondatabase/serverless**: PostgreSQL serverless connection
- **drizzle-orm**: Type-safe database ORM
- **@tanstack/react-query**: Server state management
- **@radix-ui/***: Accessible UI primitives
- **wouter**: Lightweight React router

### Development Dependencies
- **vite**: Build tool and development server
- **tsx**: TypeScript execution for development
- **esbuild**: Production build bundling
- **tailwindcss**: Utility-first CSS framework

### UI Dependencies
- **shadcn/ui**: Pre-built accessible components
- **class-variance-authority**: Component variant management
- **clsx**: Conditional class name utility
- **lucide-react**: Icon library

## Deployment Strategy

### Build Process
1. **Client Build**: Vite builds React application to `/dist/public`
2. **Server Build**: esbuild bundles Express server to `/dist/index.js`
3. **Database Setup**: Drizzle migrations applied via `db:push` command
4. **Environment Variables**: DATABASE_URL required for database connection

### Production Configuration
- **Node Environment**: Production mode with optimized builds
- **Static Assets**: Client build served from `/dist/public`
- **Database**: PostgreSQL connection via environment variable
- **Session Storage**: PostgreSQL-backed session store

### Development Workflow
- **Hot Reload**: Vite middleware integration for instant updates
- **TypeScript**: Real-time type checking across all modules
- **Database**: Local or cloud PostgreSQL instance
- **API Development**: Express server with automatic restart

## User Preferences

Preferred communication style: Simple, everyday language.

## Changelog

Changelog:
- July 07, 2025. Initial setup
- July 07, 2025. Added PostgreSQL database with Drizzle ORM integration, replaced in-memory storage with database storage